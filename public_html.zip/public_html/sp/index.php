<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Moore Future</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" type="text/css" href="sp/css/skel.css" />
			<link rel="stylesheet" type="text/css" href="sp/css/style.css" />
			<link rel="stylesheet" type="text/css" href="sp/css/style-xlarge.css" />
			<link rel="stylesheet" type="text/css" href="sp/css/ie/v8.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
	</head>
	<body class="landing">

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html">Moore Future</a></h1>
				<nav id="nav">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="Jobsearch.html">Job Search</a></li>
						<li><a href="4yearplan.html">4 Year Plan</a></li>
						<li><a href="ResumeBuild.html">Resume builder</a></li>
						<li><a href="Resources.html">Resources</a></li>
						<li><a href="Profile.html">Profile</a></li>
						
					</ul>
				</nav>
			</header>

		<!-- Banner -->
			<section id="banner">
				<h2>Moore Future</h2>
				<p>Here to help you get on track for a brighter future</p>
				<ul class="actions">
					<li>
						<a href="#one" class="button big">Plan Now</a>
					</li>
				</ul>
			</section>

		<!-- One -->
			<section id="one" class="wrapper style1 align-center">
				<div class="container">
<?php
include 'Dbconnect.php';
// index2.html
if($_GET['user_level'] == 1){
	$buisness=true;
}else{
	$buisness=false;
}
if($_GET['user_level'] == 2){
	$admin=true;
}else{
	$admin=false;
}

function mysql_safe_string($args) {
    $value = trim($args);
    if(empty($args))           return 'NULL';
    elseif(is_numeric($args))  return $value;
    else {
    	return "'".mysql_real_escape_string($args)."'";
		 }                        
}

function mysql_safe_query($query) {
    $args = array_slice(func_get_args(),1);
    $args = array_map('mysql_safe_string',$args);
    return mysql_query(vsprintf($query,$args));
}

function redirect($uri) {
    header('location:'.$uri);
    exit;
}


$result = mysql_safe_query('SELECT * FROM posts ORDER BY date DESC');

if(!mysql_num_rows($result)) {
    echo 'There hace been no posts yet.';
} else {
    while($row = mysql_fetch_assoc($result)) {
        echo '<h2>'.$row['title'].'</h2>';
        $body = substr($row['body'], 0, 300);
        echo nl2br($body).'...<br/>';
        echo '<a href="post_view.php?id='.$row['id'].'">Read More</a> | ';
        
        if(admin == true or buisness == true){echo '<a href="post_view.php?id='.$row['id'].'#comments">'.$row['num_comments'].' comments</a>';}    
        echo '<hr/>';
    }
}

echo <<<HTML
<a href="post_add.php">+ New Post</a>
HTML;
?>
				</div>
			</section>

		<!-- Two -->
			
		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<div class="row">
						<section class="4u 6u(medium) 12u$(small)">
							<h3>Having Trouble?</h3>
							<p>Feel free to contact your school's Career Developement Cordinator with any questions. They're always happy to help!</p>
							
						</section>
						<section class="4u 6u$(medium) 12u$(small)">
							<h3></h3>
							<p></p>
							<ul class="alt">
								<li><b style="color:white">Union Pines: </b>Stacey Patterson <br> Email: <a href=mailto:spatterson@ncmcs.org?Subject=Moore%20Future%20Help>spatterson@ncmcs.org</a> </li>
								<li><b style="color:white">Pinecrest: </b>Karen Raliski <br> Email: <a href=mailto:kraliski@ncmcs.org?Subject=Moore%20Future%20Help>kraliski@ncmcs.org</a></li>
								<li><b style="color:white">North Moore: </b>Kyle Greene <br> Email: <a href=mailto:kgreene@ncmcs.org?Subject=Moore%20Future%20Help>kgreene@ncmcs.org</a></li>
							</ul>
						</section>
						<section class="4u$ 12u$(medium) 12u$(small)">
							<h3>Contact Us</h3>
							<ul class="icons">
								<li><a href="https://www.twitter.com/MooreForward" class="icon rounded fa-twitter"><span class="label">Twitter</span></a></li>
								<li><a href="https://www.facebook.com/mooreforward" class="icon rounded fa-facebook"><span class="label">Facebook</span></a></li>
								<li><a href="https://www.linkedin.com/company/moore-forward" class="icon rounded fa-linkedin"><span class="label">LinkedIn</span></a></li>
							</ul>
							<ul class="tabular">
								<li>
									<h3>Address</h3>
									108b East Main St<br>
									Aberdeen NC, 28315
								</li>
								<li>
									<h3>Mail</h3>
									<a href="#">someone@untitled.tld</a>
								</li>
								<li>
									<h3>Phone</h3>
									(555) 555-5555
								</li>
							</ul>
						</section>
					</div>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li>
						<li>Design: <a href="http://templated.co">TEMPLATED</a></li>
						
					</ul>
				</div>
			</footer>

	</body>
</html>
